package agenda;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import org.junit.jupiter.api.Test;

class ContatoTest {
	
	private Contato contatoBase;
	private Contato novoContato;
	private Contato contatoDiferente;

    @BeforeEach
    void preparaContatos() {
        this.contatoBase = new Contato("Matheus", "Gaudencio", "555-5551");
        this.novoContato = new Contato("Matheus", "Gaudencio", "4002-8922");
        this.contatoDiferente = new Contato("Felipe", "vinicius", "5478-6325");
    }


	@Test
	void testGetNomeSobrenome() {
		String nomeSobrenome = this.contatoBase.getNomeSobrenome();
		assertEquals("Matheus Gaudencio", nomeSobrenome);
	}

	@Test
	void testEqualsObject() {
		boolean resultado = this.contatoBase.equals(novoContato);
		assertEquals(true, resultado);
		resultado = this.contatoBase.equals(contatoDiferente);
		assertEquals(false, resultado);
		
	}

	@Test
	void testToString() {
		String descricao = this.contatoBase.toString();
		assertEquals("Matheus Gaudencio\n555-5551\n", descricao);
	}

}
