package agenda;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class AgendaTest {
	
	private Agenda agenda;
	
	@BeforeEach
	void preparaAgenda() {
		this.agenda = new Agenda();
	}
	
	@Test
	void testCadastraContato() {
		// Cadastrar um novo contato em posição vazia
		this.agenda.cadastraContato(1, "Matheus", "Gaudencio","4002-8922");
		Contato contato = this.agenda.getContato(1);
		assertNotNull(contato);
		
		// Cadastrar novo contato em posição existente
		this.agenda.cadastraContato(1, "Felipe", "Vinicius", "8845-8596");
		contato = this.agenda.getContato(1);
		assertEquals("Felipe Vinicius\n8845-8596\n", contato.toString());
		
		
		// Cadastrar contato em uma posição acima do limite
		Exception exception = assertThrows(IndexOutOfBoundsException.class, () -> {
			this.agenda.cadastraContato(101, "VInicius", "Felipe", "8845-7423");
		});
		assertEquals("POSIÇÃO INVÁLIDA", exception.getMessage());
		
		// Cadastrar contato com o nome null
		exception = assertThrows(NullPointerException.class, () -> {
			this.agenda.cadastraContato(99, null, "carlos", "8845-7423");
		});
		assertEquals("CONTATO INVÁLIDO", exception.getMessage());
		
		// Cadastra contato com o nome vazio
		exception = assertThrows(IllegalArgumentException.class, () -> {
			this.agenda.cadastraContato(99, "", "carlos", "8845-7423");
		});
		assertEquals("CONTATO INVÁLIDO", exception.getMessage());
		
		// Cadastrar contato na posição limite 100
		this.agenda.cadastraContato(100, "Matheus", "Gaudencio","4002-8922");
		contato = this.agenda.getContato(100);
		assertNotNull(contato);
		
		// Cadastrar contato abaixo da posição miníma
		exception = assertThrows(IndexOutOfBoundsException.class, () -> {
			this.agenda.cadastraContato(0, "Matheus", "Gaudencio","4002-8922");
			});
			assertEquals("POSIÇÃO INVÁLIDA", exception.getMessage());
	}

	@Test
	void testAdicionaFavorito() {
		this.agenda.cadastraContato(5, "Matheus", "Gaudencio", "4002-8922");
		this.agenda.adicionaFavorito(5, 1);
		Contato contato = this.agenda.getContato(5);
		assertEquals(true, contato.ehFavorito());
		
		Exception exception = assertThrows(IndexOutOfBoundsException.class, () -> {
			this.agenda.adicionaFavorito(-1, 2);
		});
		
		exception = assertThrows(IllegalArgumentException.class, () -> {
			this.agenda.adicionaFavorito(5, 2);
		});
		
		assertEquals("CONTATO JÁ CADASTRADO NA LISTA DE FAVORITOS", exception.getMessage());
		
	}
	

	@Test
	void testRemoveFavorito() {
		this.agenda.cadastraContato(5, "Matheus", "Gaudencio", "5896-1245");
		this.agenda.adicionaFavorito(5, 1);
		
		boolean resultado = this.agenda.removeFavorito(1);
		assertEquals(true, resultado);
		
		Contato contato = this.agenda.getContato(5);
		assertEquals(false, contato.ehFavorito());
		
		resultado = this.agenda.removeFavorito(2);
		assertEquals(false, resultado);
		
	}

	@Test
	void testValidarPosicao() {
		boolean resultado = this.agenda.validarPosicao(5, 100);
		assertEquals(true, resultado);
		
		resultado = this.agenda.validarPosicao(-1, 100);
		assertEquals(false, resultado);
	}

	@Test
	void testValidarCampo() {
		Exception exception = assertThrows(NullPointerException.class, () -> {
			this.agenda.validarCampo(null);
		});
		
		exception = assertThrows(IllegalArgumentException.class, () -> {
			this.agenda.validarCampo("");
		});
		
		boolean resultado = this.agenda.validarCampo("Matheus");
		assertEquals(true, resultado);
	}
}
