package agenda;

/**
 * Uma agenda que mantém uma lista de contatos com posições. Podem existir 100 contatos.
 *
 * @author Thales Barros - 121110595
 *
 */

public class Agenda {

    private static final int TAMANHO_AGENDA = 100;

    private static final int TAMANHO_AGENDA_FAVORITOS = 10;

    private Contato[] contatos; //apenas uma simplificacao de contato

    private Contato[] favoritos;

    /**
     * Cria uma agenda.
     */
    public Agenda() {
        this.contatos = new Contato[TAMANHO_AGENDA];
        this.favoritos = new Contato[TAMANHO_AGENDA_FAVORITOS];
    }


    /**
     * Acessa a lista de contatos mantida.
     *
     * @return O array de contatos.
     */
    
    public Contato[] getContatos() {
        return this.contatos.clone();
    }

    /**
     * Acessa os dados de um contato específico.
     * @param posicao Posição do contato na agenda.
     * @return Dados do contato. Null se não há contato na posição.
     */
    
    public Contato getContato(int posicao) { 
    	posicao = posicao - 1;
    	return this.contatos[posicao];
    }

    /**
     * Cadastra um contato em uma posição. Um cadastro em uma posição que já existe sobrescreve o anterior.
     * @param posicao Posição do contato.
     * @param nome Nome do contato.
     * @param sobrenome Sobrenome do contato.
     * @param telefone Telefone do contato.
     */
    
    public void cadastraContato(int posicao, String nome, String sobrenome, String telefone) {
        posicao = posicao -1;
    	if(validarPosicao(posicao, TAMANHO_AGENDA)) {
            if(validarCampo(nome) && validarCampo(sobrenome) && checarCadastro(nome, sobrenome)) {
            	if(validarCampo(telefone)) {
            		Contato novoContato = new Contato(nome, sobrenome, telefone);
                    this.contatos[posicao] = novoContato;
            	}
            } else {
            	throw new IllegalArgumentException("CONTATO JA CADASTRADO");
            }
            
        } else {
            throw new IndexOutOfBoundsException("POSIÇÃO INVÁLIDA");
        }
    }

    /**
     * Adiciona um contato em uma posição de uma lista de favoritos. Um cadastro em uma posição que já existe sobrescreve o anterior.
     * @param contatoPosicao Posição do contato.
     * @param posicao posição.
     */

    public void adicionaFavorito(int contatoPosicao, int posicao) {
    	posicao = posicao - 1;
    	contatoPosicao = contatoPosicao -1;
        if (validarPosicao(contatoPosicao, TAMANHO_AGENDA) &&
            validarPosicao(posicao, TAMANHO_AGENDA_FAVORITOS) &&
            validarContatoFavorito(contatoPosicao)) {
            if(checarPosicaoFavorito(posicao)) {
                this.favoritos[posicao].setEhFavorito(false);
            }

            Contato contato = this.contatos[contatoPosicao];
            this.favoritos[posicao] = contato;
            this.favoritos[posicao].setEhFavorito(true);
        } else {
        	throw new IndexOutOfBoundsException("POSIÇÃO INVÁLIDA");
        }
        
    }

    /**
     * Remove um contato da lista de favoritos.
     * @param posicao posição.
     */

    public boolean removeFavorito(int posicao) {
    	posicao = posicao - 1; 
        validarPosicao(posicao, TAMANHO_AGENDA_FAVORITOS);
        if(checarPosicaoFavorito(posicao)) {
            this.favoritos[posicao].setEhFavorito(false);
            this.favoritos[posicao] = null;
            return true;
        }
        return false;
    }

    /**
     * Negar o usuário de cadastrar um nome/sobrenome vazio na agenda de contatos
     * @param nome nome do contato.
     * @param sobrenome sobrenome do contato.
     * @return
     */
    
    private boolean checarCadastro(String nome, String sobrenome) {
        boolean contatoNaoCadastrado = true;
        Contato novoContato = new Contato(nome, sobrenome, "");
        for (Contato contato: contatos) {
            if(contato != null && contato.equals(novoContato)) {
            	contatoNaoCadastrado = false;
            	break;
            }
        }
        return contatoNaoCadastrado;
    }
    
    public boolean validarPosicaoAgenda(int posicao) {
    	posicao = posicao - 1;
        return validarPosicao(posicao, TAMANHO_AGENDA);
    }

    /**
     * Não permitir que o usuário cadastre o contato em uma posição inválida na agenda.
     * @param posicao posição.
     * @param posicaoMaxima posicaoMaxima da agenda.
     * @return
     */
    
    public boolean validarPosicao(int posicao, int posicaoMaxima) {
        int posicaoMinima = 0;
        boolean posicaoValida = false;
        if(posicao >= posicaoMinima && posicao < posicaoMaxima) {
            posicaoValida = true;
        }
        return posicaoValida;
    }

    public boolean validarCampo(String campo) {
        if(campo == null) {
            throw new NullPointerException("CONTATO INVÁLIDO");
        } else if (campo.isEmpty()){
            throw new IllegalArgumentException("CONTATO INVÁLIDO");
        }
        return true;
    }

    /** Não permitir o usuário cadastar 2 vezes o mesmo contato na lista de favoritos.
     * @param posicao posição.
     * @return
     */

    private boolean validarContatoFavorito(int posicao) {
        if (this.contatos[posicao].ehFavorito()) {
            throw new IllegalArgumentException("CONTATO JÁ CADASTRADO NA LISTA DE FAVORITOS");
        }
        return true;
    }

    /**
     * Checa posição favorito.
     * @param posicao posição
     * @return
     */

    private boolean checarPosicaoFavorito(int posicao) {
        if (this.favoritos[posicao] != null) {
            return true;
        }
        return false;
    }

    /**
     * Exibe contato pela posição.
     * @param posicao posição.
     * @return
     */

    public String exibeContato(int posicao) {
    	posicao = posicao - 1;
        this.validarPosicao(posicao, TAMANHO_AGENDA);
        return this.contatos[posicao].toString();
    }
    
    private static String formataContato(int posicao, Contato contato) {

        return posicao + " - " + contato.getNomeSobrenome();
    }

    /**
     * Lista todos os contato cadastrados na agenda, passando posicção, nome, sobrenome e telefone.
     * @return
     */
    
    public String listarContatos() {
        String listaContatos = "";
        for (int i = 0; i < contatos.length; i++) {
            if (contatos[i] != null) {
                listaContatos += formataContato(i+1, contatos[i]) + '\n';
            }
        }
        return listaContatos;
    }

    /**
     * Lista os contatos adicionados na lista de favoritos.
     * @return
     */

    public String listarfavoritos() {
        String listaFavoritos = "";
        for (int i = 0; i < favoritos.length; i++) {
            if (favoritos[i] != null) {
                listaFavoritos += formataContato(i+1, favoritos[i]) + '\n';
            }
        }
        return listaFavoritos;
    }

    @Override
    public String toString() {
        return this.listarContatos();
    }
    /**
     * Formata um contato para impressão na interface.
     *
     * @param posicao A posição do contato (que é exibida)/
     * @param contato O contato a ser impresso.
     * @return A String formatada.
     */
}

