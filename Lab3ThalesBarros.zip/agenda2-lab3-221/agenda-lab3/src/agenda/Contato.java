package agenda;

import java.util.Objects;

/**
 * Classe criada para manipular nome, sobrenome, telefone da agenda.
 *
 * @author Thales Barros - 121110595
 *
 */

public class Contato {

    private String nome;
    private String sobrenome;
    private String telefone;
    private boolean ehFavorito;

    public Contato(String nome, String sobrenome, String telefone) {
        this.nome = nome;
        this.sobrenome = sobrenome;
        this.telefone = telefone;
        this.ehFavorito = false;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getSobrenome() {
        return sobrenome;
    }

    public void setSobrenome(String sobrenome) {
        this.sobrenome = sobrenome;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public boolean ehFavorito() {
        return ehFavorito;
    }

    public void setEhFavorito(boolean ehFavorito) {
        this.ehFavorito = ehFavorito;
    }

    public String getNomeSobrenome() {
        return this.nome + " " + this.sobrenome;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Contato contato = (Contato) o;
        return Objects.equals(nome, contato.nome) && Objects.equals(sobrenome, contato.sobrenome);
    }

    @Override
    public String toString() {
        String descricao = "";
        if (this.ehFavorito){
            descricao = "❤\uFE0F ";
        }
        descricao += nome + " " + sobrenome + '\n'
                + telefone + '\n';
        return descricao;
    }
}

